/* Kleine Laufzeit für die Design-Vorlage im Browser.
   Unterstützt: {{ a.b.c }} in Text und Attributen, <sc-if value="{{ x }}">,
   <sc-for list="{{ xs }}" as="x">, Ereignisse onClick/onChange/onInput/onPointerUp="{{ fn }}",
   Komponenten "class X extends DCLogic { state; setState(); renderVals() }". */
(function () {
  const HOLE = /\{\{\s*([A-Za-z_$][\w$]*(?:\.[\w$]+)*)\s*\}\}/g;
  const ONLY_HOLE = /^\s*\{\{\s*([A-Za-z_$][\w$]*(?:\.[\w$]+)*)\s*\}\}\s*$/;
  const BOOL_ATTRS = { selected: 1, checked: 1, disabled: 1, readonly: 1, required: 1, hidden: 1, open: 1 };
  const SKIP_ATTRS = /^hint-/;

  function lookup(path, scopes) {
    const parts = path.split('.');
    for (let i = scopes.length - 1; i >= 0; i--) {
      const sc = scopes[i];
      if (sc && Object.prototype.hasOwnProperty.call(sc, parts[0])) {
        let v = sc;
        for (const p of parts) { if (v === null || v === undefined) return undefined; v = v[p]; }
        return v;
      }
    }
    return undefined;
  }

  function resolveAttr(value, scopes) {
    const m = value.match(ONLY_HOLE);
    if (m) return lookup(m[1], scopes);
    return value.replace(HOLE, (_, p) => { const v = lookup(p, scopes); return v === undefined || v === null ? '' : String(v); });
  }

  function render(node, scopes, out) {
    if (node.nodeType === 3) {
      const t = node.nodeValue;
      out.appendChild(document.createTextNode(HOLE.test(t) ? t.replace(HOLE, (_, p) => { const v = lookup(p, scopes); return v === undefined || v === null ? '' : String(v); }) : t));
      HOLE.lastIndex = 0;
      return;
    }
    if (node.nodeType !== 1) return;
    const tag = node.localName;
    if (tag === 'sc-if') {
      if (lookup((node.getAttribute('value') || '').replace(/[{}\s]/g, ''), scopes)) renderChildren(node, scopes, out);
      return;
    }
    if (tag === 'sc-for') {
      const list = lookup((node.getAttribute('list') || '').replace(/[{}\s]/g, ''), scopes) || [];
      const as = node.getAttribute('as') || 'item';
      list.forEach((item, i) => renderChildren(node, scopes.concat([{ [as]: item, [as + 'Index']: i }]), out));
      return;
    }
    const el = document.createElementNS(node.namespaceURI, tag);
    for (const a of node.attributes) {
      const name = a.name, val = a.value;
      if (SKIP_ATTRS.test(name)) continue;
      if (name.startsWith('on') && ONLY_HOLE.test(val)) {
        const fn = resolveAttr(val, scopes);
        if (typeof fn === 'function') el.addEventListener(name.slice(2), fn);
        continue;
      }
      if (val.indexOf('{{') < 0) { el.setAttribute(name, val); continue; }
      const v = resolveAttr(val, scopes);
      if (BOOL_ATTRS[name]) { if (v) el.setAttribute(name, ''); continue; }
      if (name === 'value' && (tag === 'input' || tag === 'textarea' || tag === 'select' || tag === 'option')) {
        const s = v === undefined || v === null ? '' : String(v);
        el.setAttribute('value', s);
        if (tag === 'textarea') el.textContent = s;
        el.__dcValue = s;
        continue;
      }
      if (v === undefined || v === null || v === false) continue;
      el.setAttribute(name, v === true ? 'true' : String(v));
    }
    renderChildren(node, scopes, el);
    if (el.__dcValue !== undefined && tag !== 'option') el.value = el.__dcValue;
    if (tag === 'select') { const o = el.querySelector('option[selected]'); if (o) el.value = o.value; }
    out.appendChild(el);
  }

  function renderChildren(node, scopes, out) {
    for (const c of node.childNodes) render(c, scopes, out);
  }

  class DCLogic {
    constructor() { this.props = {}; this.state = this.state || {}; }
    setState(patch) {
      this.state = { ...this.state, ...(typeof patch === 'function' ? patch(this.state) : patch) };
      if (this.__mount) this.__mount.schedule();
    }
  }

  function mount(Comp, root, tpl, props, opts) {
    opts = opts || {};
    const comp = new Comp();
    comp.props = props || {};
    if (opts.storageKey && opts.persist) {
      try {
        const saved = JSON.parse(localStorage.getItem(opts.storageKey) || 'null');
        if (saved && typeof saved === 'object') {
          const st = { ...comp.state };
          for (const k of opts.persist) if (saved[k] !== undefined) st[k] = k === 'f' ? { ...comp.state.f, ...saved.f } : saved[k];
          comp.state = st;
        }
      } catch (x) {}
    }
    let pending = false;
    const m = {
      schedule() { if (pending) return; pending = true; Promise.resolve().then(() => { pending = false; m.draw(); }); },
      draw() {
        let vals;
        try { vals = comp.renderVals(); } catch (e) { console.error(e); root.textContent = 'Es ist ein Fehler aufgetreten. Bitte laden Sie die Seite neu.'; return; }
        const active = document.activeElement, activeId = active && active.id, sel = active && active.selectionStart;
        const frag = document.createDocumentFragment();
        renderChildren(tpl.content, [vals], frag);
        root.replaceChildren(frag);
        if (activeId) { const el = document.getElementById(activeId); if (el && el !== document.activeElement) { try { el.focus({ preventScroll: true }); if (sel !== null && sel !== undefined && el.setSelectionRange) el.setSelectionRange(sel, sel); } catch (x) {} } }
        if (opts.storageKey && opts.persist) {
          try { const o = {}; for (const k of opts.persist) o[k] = comp.state[k]; localStorage.setItem(opts.storageKey, JSON.stringify(o)); } catch (x) {}
        }
      }
    };
    comp.__mount = m;
    m.draw();
    return comp;
  }

  window.DCLogic = DCLogic;
  window.DC = { mount, render, lookup };
})();
