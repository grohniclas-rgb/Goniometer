# Web-Formular (eigenständige Seite)

`anmeldung.html` ist der Anmeldebogen als normale Webseite. Der AMB+-Server liefert sie unter `/f/<token>` aus.

## Dateien
- `build_web.py` – baut `anmeldung.html` aus der Design-Vorlage `project/Main.dc.html`. Nach jeder Änderung an der Vorlage erneut ausführen.
- `dc_runtime.js` – kleine Laufzeit, die die Vorlage im Browser ausführt (Platzhalter, Bedingungen, Listen, Ereignisse, Zustand).
- `anmeldung.html` – fertige Seite (wird erzeugt, nicht von Hand ändern).

## Verhalten
- Pflichtfelder werden geprüft; der Testmodus ist aus. Zum Durchklicken `?test=1` an den Link hängen.
- Eingaben bleiben im Browser gespeichert, bis die Anmeldung abgeschickt ist (Fortsetzen möglich).
- Auf der Abschluss-Seite sendet „Anmeldung an die Praxis senden“ die Exportdatei (`amb-plus/anmeldung`) an `/api/v1/f/<token>/absenden`. Danach ist der Link verbraucht.
- Der Server setzt Praxisname und die E-Mail-Adresse aus dem Link ein.
- Die Seite ist offline-fähig geladen (kein Nachladen außer der Schrift von Google Fonts; für den Betrieb besser lokal einbinden).

## Getestet (Chrome, 420 px breit)
Alle 20 Schritte durchklicken, Texteingabe, Auswahl-Chips, Körperschema, Schmerzregler, Zwischenspeicher nach Neuladen, Absenden an den Server, Link danach „bereits abgeschickt“, PDF über Connector im Importordner.
