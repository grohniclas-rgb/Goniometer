#!/usr/bin/env python3
"""AMB+ – Goniometer-Messprotokoll als A4-PDF.

Eingabe: Messung der Goniometer-App (Schema amb-plus/goniometer), vom Server ergänzt um
         "praxis" und "erstellt".
Ausgabe: PDF mit einer Zeile je Gelenk und Bewegung (rechts, links, Seitendifferenz).
         Dateiname wie bei der Anmeldung, damit der THEORG-Blitzimport den Patienten findet:
         Nachname_Vorname_TT.MM.JJJJ_Goniometer_JJJJ-MM-TT.pdf
"""
import datetime as dt
import io
import re

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from pdf_uebersicht import ACCENT, FONT, FONT_B, INK, LINE, MUTED, ST_SMALL, ST_TITLE, ST_VAL, esc

ABWEICHUNG_PROZENT = 10
HINWEIS = 'Goniometer-Messung nach der Neutral-0-Methode, Werte in Grad.'
AUFFAELLIG = colors.HexColor('#FCF3D9')
ROT = colors.HexColor('#C62828')
ST_TH = ParagraphStyle('th', fontName=FONT_B, fontSize=8.4, leading=10, textColor=colors.white)


def datum_de(iso):
    return '.'.join(reversed(iso[:10].split('-')))


def zeilen(messungen):
    """Je Gelenk und Bewegung eine Zeile, Reihenfolge wie gemessen."""
    tab = {}
    for m in messungen:
        tab.setdefault((m['gelenk'], m['bewegung']), {})[m['seite']] = m
    out = []
    for (gelenk, bewegung), seiten in tab.items():
        r, l = seiten.get('rechts'), seiten.get('links')
        diff = None
        if r and l and max(r['grad'], l['grad']) > 0:
            diff = abs(r['grad'] - l['grad']) / max(r['grad'], l['grad']) * 100
        out.append((gelenk, bewegung, r, l, diff))
    return out


def wert(m):
    if not m:
        return '–'
    return '%d°%s' % (m['grad'], '*' if m['quelle'] == 'manuell' else '')


def build(daten, out):
    p = daten['patient']
    praxis = daten.get('praxis') or ''
    erstellt = dt.datetime.fromisoformat(daten['erstellt']).strftime('%d.%m.%Y, %H:%M Uhr')
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=12 * mm, bottomMargin=15 * mm,
                            title='Goniometer – %s, %s' % (p['nachname'], p['vorname']), author=praxis)
    avail = A4[0] - doc.leftMargin - doc.rightMargin

    story = [Paragraph(esc(praxis) + ' · Goniometer-Messung · erstellt am ' + esc(erstellt), ST_SMALL), Spacer(1, 2),
             Paragraph(esc('%s %s' % (p['vorname'], p['nachname'])) + ' · geb. ' + esc(datum_de(p['geburtsdatum'])), ST_TITLE),
             Spacer(1, 2)]
    hr = Table([['']], colWidths=[avail], rowHeights=[1])
    hr.setStyle(TableStyle([('LINEBELOW', (0, 0), (-1, -1), 1.2, INK)]))
    story += [hr, Spacer(1, 8)]

    data = [[Paragraph(t, ST_TH) for t in ('Gelenk', 'Bewegung', 'Rechts', 'Links', 'Seitendifferenz')]]
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
        ('FONTNAME', (0, 1), (-1, -1), FONT), ('FONTSIZE', (0, 1), (-1, -1), 9.5),
        ('TEXTCOLOR', (0, 1), (-1, -1), INK),
        ('ALIGN', (2, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LINEBELOW', (0, 1), (-1, -1), 0.4, LINE),
        ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]
    vorher = None
    for i, (gelenk, bewegung, r, l, diff) in enumerate(zeilen(daten['messungen']), start=1):
        data.append([Paragraph(esc(gelenk) if gelenk != vorher else '', ST_VAL), Paragraph(esc(bewegung), ST_VAL),
                     wert(r), wert(l), '–' if diff is None else '%d %%' % round(diff)])
        vorher = gelenk
        if diff is not None and diff > ABWEICHUNG_PROZENT:
            style += [('BACKGROUND', (0, i), (-1, i), AUFFAELLIG),
                      ('TEXTCOLOR', (4, i), (4, i), ROT), ('FONTNAME', (4, i), (4, i), FONT_B)]
    t = Table(data, colWidths=[38 * mm, 48 * mm, 28 * mm, 28 * mm, avail - 142 * mm], repeatRows=1)
    t.setStyle(TableStyle(style))
    story += [t, Spacer(1, 6)]

    legende = 'Hervorgehoben: Seitendifferenz über %d %% (bezogen auf den größeren Wert).' % ABWEICHUNG_PROZENT
    if any(m['quelle'] == 'manuell' for m in daten['messungen']):
        legende += ' * = von Hand eingegeben, sonst mit dem Smartphone-Sensor gemessen.'
    else:
        legende += ' Alle Werte mit dem Smartphone-Sensor gemessen.'
    story.append(Paragraph(esc(legende), ParagraphStyle('l', parent=ST_SMALL, textColor=MUTED)))

    def on_page(canv, d):
        canv.saveState()
        canv.setFont(FONT, 7.5)
        canv.setFillColor(MUTED)
        canv.drawString(doc.leftMargin, 8 * mm, HINWEIS)
        canv.drawRightString(A4[0] - doc.rightMargin, 8 * mm, 'Seite %d' % d.page)
        canv.restoreState()

    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


def build_bytes(daten):
    buf = io.BytesIO()
    build(daten, buf)
    return buf.getvalue()


def dateiname(daten):
    p = daten['patient']
    teile = [p['nachname'], p['vorname'], datum_de(p['geburtsdatum']), 'Goniometer', daten['erstellt'][:10]]
    return re.sub(r'[^0-9A-Za-zÄÖÜäöüß._-]+', '-', '_'.join(teile)) + '.pdf'
