#!/usr/bin/env python3
"""AMB+-Server – Prototyp (Python 3, Standardbibliothek + reportlab für das PDF).

Was er kann:
  * Link-Anforderung durch den Patienten  POST /api/v1/link {praxis, email}
    -> Einmal-Link (14 Tage), E-Mail landet im Prototyp als Datei in outbox/
  * Formularseite                          GET  /f/<token>
    (Prototyp: Testseite, die eine Beispielanmeldung absendet; das echte Formular
     wird später hier eingebunden und sendet dieselbe Exportdatei)
  * Anmeldung annehmen                     POST /api/v1/f/<token>/absenden  (JSON amb-plus/anmeldung)
    -> PDF erzeugen, verschlüsselt ablegen*, Praxis benachrichtigen (E-Mail ohne Inhalte)
  * Praxis-API für den Connector           GET /api/v1/praxis/status, .../anmeldungen?status=neu,
                                           .../anmeldungen/<id>/pdf, POST .../anmeldungen/<id>/abgeholt
  * Praxisportal                           GET /portal  (Browser, Anmeldung mit Praxis-Kennung + Schlüssel)
    -> Liste, PDF-Download, Link an Patienten senden, Einrichtungslink für das Goniometer
  * Goniometer-App                         GET  /goniometer/
  * Goniometer-Messung annehmen            POST /api/v1/praxis/messungen  (JSON amb-plus/goniometer,
                                           Bearer Geräte-Schlüssel) -> PDF wie eine Anmeldung für den Connector
  * Aufräumen: abgeholte Anmeldungen nach 30 Tagen, alle nach 90 Tagen löschen

* Prototyp: Ablage im Dateisystem unter data/. Für den Betrieb: Festplattenverschlüsselung
  oder Verschlüsselung je Datei, HTTPS über Reverse Proxy, echter E-Mail-Versand.

Start:  python3 amb_server.py [--port 8080] [--data ./data]
"""
import argparse
import base64
import datetime as dt
import html
import json
import os
import re
import secrets
import shutil
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pdf_goniometer  # noqa: E402
import pdf_uebersicht  # noqa: E402

LINK_TAGE = 14
LOESCHEN_NACH_ABHOLUNG_TAGE = 30
LOESCHEN_SPAETESTENS_TAGE = 90


# ---------- Ablage
class Ablage:
    def __init__(self, wurzel):
        self.wurzel = wurzel
        for d in ('links', 'anmeldungen', 'outbox'):
            os.makedirs(os.path.join(wurzel, d), exist_ok=True)
        self.praxen_datei = os.path.join(wurzel, 'praxen.json')
        if not os.path.exists(self.praxen_datei):
            self._schreib(self.praxen_datei, {'testpraxis': {'name': 'Physiotherapie Beispiel', 'schluessel': secrets.token_urlsafe(24), 'email': 'anmeldung@praxis-beispiel.de'}})
        self.sperre = threading.Lock()
        # Geräte-Schlüssel (Handy/Tablet mit Goniometer): darf nur Messungen senden, keine Anmeldungen lesen
        praxen = self.praxen()
        if any('geraete_schluessel' not in p for p in praxen.values()):
            for p in praxen.values():
                p.setdefault('geraete_schluessel', secrets.token_urlsafe(24))
            self._schreib(self.praxen_datei, praxen)

    def _lies(self, p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)

    def _schreib(self, p, obj):
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
        os.replace(tmp, p)

    def praxen(self):
        return self._lies(self.praxen_datei)

    def praxis_per_schluessel(self, s):
        for pid, p in self.praxen().items():
            if s and secrets.compare_digest(p['schluessel'], s):
                return pid, p
        return None, None

    def praxis_per_geraeteschluessel(self, s):
        for pid, p in self.praxen().items():
            if s and secrets.compare_digest(p['geraete_schluessel'], s):
                return pid, p
        return None, None

    # Links
    def link_anlegen(self, praxis_id, email):
        token = secrets.token_urlsafe(24)
        self._schreib(os.path.join(self.wurzel, 'links', token + '.json'), {
            'praxis': praxis_id, 'email': email, 'erstellt': jetzt(), 'gueltig_bis': jetzt(LINK_TAGE), 'verbraucht': False})
        return token

    def link(self, token):
        if not re.fullmatch(r'[A-Za-z0-9_-]{20,}', token or ''):
            return None
        p = os.path.join(self.wurzel, 'links', token + '.json')
        return self._lies(p) if os.path.exists(p) else None

    def link_verbrauchen(self, token):
        p = os.path.join(self.wurzel, 'links', token + '.json')
        d = self._lies(p)
        d['verbraucht'] = True
        self._schreib(p, d)

    # Anmeldungen
    def anmeldung_speichern(self, praxis_id, daten, pdf_bytes, dateiname, art='Anmeldung'):
        aid = dt.datetime.now().strftime('%Y%m%d-%H%M%S-') + secrets.token_hex(3)
        d = os.path.join(self.wurzel, 'anmeldungen', aid)
        os.makedirs(d)
        self._schreib(os.path.join(d, 'anmeldung.json'), daten)
        with open(os.path.join(d, 'uebersicht.pdf'), 'wb') as f:
            f.write(pdf_bytes)
        self._schreib(os.path.join(d, 'meta.json'), {'id': aid, 'praxis': praxis_id, 'art': art, 'dateiname': dateiname, 'status': 'neu',
                                                     'eingang': jetzt(), 'abgeholt': None, 'patient_kurz': kurzname(daten)})
        return aid

    def anmeldungen(self, praxis_id, status=None):
        out = []
        basis = os.path.join(self.wurzel, 'anmeldungen')
        for aid in sorted(os.listdir(basis)):
            mp = os.path.join(basis, aid, 'meta.json')
            if not os.path.exists(mp):
                continue
            m = self._lies(mp)
            if m['praxis'] == praxis_id and (status is None or m['status'] == status):
                out.append(m)
        return out

    def meta(self, praxis_id, aid):
        mp = os.path.join(self.wurzel, 'anmeldungen', aid, 'meta.json')
        if not re.fullmatch(r'[0-9A-Za-z-]+', aid or '') or not os.path.exists(mp):
            return None
        m = self._lies(mp)
        return m if m['praxis'] == praxis_id else None

    def pdf_pfad(self, aid):
        return os.path.join(self.wurzel, 'anmeldungen', aid, 'uebersicht.pdf')

    def abgeholt(self, praxis_id, aid):
        m = self.meta(praxis_id, aid)
        if not m:
            return False
        m['status'], m['abgeholt'] = 'abgeholt', jetzt()
        self._schreib(os.path.join(self.wurzel, 'anmeldungen', aid, 'meta.json'), m)
        return True

    def aufraeumen(self):
        basis = os.path.join(self.wurzel, 'anmeldungen')
        n = 0
        for aid in os.listdir(basis):
            mp = os.path.join(basis, aid, 'meta.json')
            if not os.path.exists(mp):
                continue
            m = self._lies(mp)
            weg = (m['abgeholt'] and m['abgeholt'] < jetzt(-LOESCHEN_NACH_ABHOLUNG_TAGE)) or m['eingang'] < jetzt(-LOESCHEN_SPAETESTENS_TAGE)
            if weg:
                shutil.rmtree(os.path.join(basis, aid))
                n += 1
        lb = os.path.join(self.wurzel, 'links')
        for f in os.listdir(lb):
            p = os.path.join(lb, f)
            if self._lies(p)['gueltig_bis'] < jetzt(-LINK_TAGE):
                os.remove(p)
        return n

    # E-Mail (Prototyp: Datei in outbox/)
    def mail(self, an, betreff, text):
        name = dt.datetime.now().strftime('%Y%m%d-%H%M%S-') + secrets.token_hex(2) + '.txt'
        with open(os.path.join(self.wurzel, 'outbox', name), 'w', encoding='utf-8') as f:
            f.write('An: %s\nBetreff: %s\n\n%s\n' % (an, betreff, text))


def lan_ip():
    """Adresse des Rechners im WLAN/LAN, damit Links auch am Handy funktionieren."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        return s.getsockname()[0]
    except OSError:
        return '127.0.0.1'
    finally:
        s.close()


def jetzt(tage=0):
    return (dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=tage)).isoformat(timespec='seconds')


def kurzname(daten):
    p = daten.get('patient') or {}
    return ((p.get('vorname') or '')[:1] + '. ' + (p.get('nachname') or '')).strip()


def pruefe_anmeldung(daten):
    if not isinstance(daten, dict) or daten.get('schema') != 'amb-plus/anmeldung':
        return 'Unbekanntes Datenformat'
    p = daten.get('patient') or {}
    if not p.get('nachname') or not p.get('vorname'):
        return 'Name fehlt'
    if not isinstance(daten.get('druck'), dict):
        return 'Druckdaten fehlen'
    return None


def pruefe_messung(daten):
    if not isinstance(daten, dict) or daten.get('schema') != 'amb-plus/goniometer':
        return 'Unbekanntes Datenformat'
    p = daten.get('patient')
    if not isinstance(p, dict) or not all(isinstance(p.get(k), str) and 0 < len(p[k].strip()) <= 80
                                          for k in ('nachname', 'vorname', 'geburtsdatum')):
        return 'Name oder Geburtsdatum fehlt'
    try:
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', p['geburtsdatum']) or dt.date.fromisoformat(p['geburtsdatum']) > dt.date.today():
            return 'Geburtsdatum ungültig'
    except ValueError:
        return 'Geburtsdatum ungültig'
    ms = daten.get('messungen')
    if not isinstance(ms, list) or not 0 < len(ms) <= 200:
        return 'Keine Messwerte'
    for m in ms:
        if not (isinstance(m, dict)
                and all(isinstance(m.get(k), str) and 0 < len(m[k]) <= 40 for k in ('gelenk', 'bewegung'))
                and m.get('seite') in ('rechts', 'links') and m.get('quelle') in ('sensor', 'manuell')
                and type(m.get('grad')) is int and 0 <= m['grad'] <= 180):
            return 'Messwert ungültig'
    return None


# ---------- HTTP
class Handler(BaseHTTPRequestHandler):
    ablage = None
    basis_url = ''
    formular_html = None  # web/anmeldung.html, falls vorhanden
    goniometer_html = None  # goniometer/index.html, falls vorhanden
    demo = False          # Demo-Modus: Link direkt anzeigen, E-Mails und Zugangsdaten auf /demo
    demo_import = ''

    def log_message(self, fmt, *a):
        sys.stdout.write('%s %s\n' % (self.command, self.path.split('?')[0]))

    # Hilfen
    def _send(self, status, body, typ='text/html; charset=utf-8', extra=None):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', typ)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, status=200, extra=None):
        self._send(status, json.dumps(obj, ensure_ascii=False), 'application/json; charset=utf-8', extra)

    def _body_json(self, max_bytes=2_000_000):
        n = int(self.headers.get('Content-Length') or 0)
        if n > max_bytes:
            return None
        try:
            return json.loads(self.rfile.read(n).decode('utf-8'))
        except (ValueError, UnicodeDecodeError):
            return None

    def _praxis_api(self):
        auth = self.headers.get('Authorization', '')
        pid, p = self.ablage.praxis_per_schluessel(auth[7:] if auth.startswith('Bearer ') else '')
        if not pid:
            self._json({'fehler': 'nicht berechtigt'}, 401)
        return pid, p

    def _praxis_portal(self):
        auth = self.headers.get('Authorization', '')
        if auth.startswith('Basic '):
            try:
                kennung, _, schl = base64.b64decode(auth[6:]).decode('utf-8').partition(':')
                pid, p = self.ablage.praxis_per_schluessel(schl)
                if pid and pid == kennung:
                    return pid, p
            except Exception:
                pass
        self._send(401, 'Anmeldung erforderlich', extra={'WWW-Authenticate': 'Basic realm="AMB+ Praxisportal", charset="UTF-8"'})
        return None, None

    # Routen
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        pfad = u.path
        if pfad == '/':
            return self._send(200, SEITE_START)
        if pfad == '/demo' and self.demo:
            return self.demo_seite()
        if pfad.startswith('/f/'):
            return self.formular(pfad[3:])
        if pfad in ('/goniometer', '/goniometer/'):
            return self.goniometer()
        if pfad == '/api/v1/praxis/status':
            pid, p = self._praxis_api()
            return pid and self._json({'praxis': p['name'], 'ok': True})
        if pfad == '/api/v1/praxis/anmeldungen':
            pid, p = self._praxis_api()
            if not pid:
                return
            st = (q.get('status') or ['neu'])[0]
            return self._json({'anmeldungen': [{'id': m['id'], 'dateiname': m['dateiname'], 'eingang': m['eingang']} for m in self.ablage.anmeldungen(pid, st)]})
        m_pdf = re.fullmatch(r'/api/v1/praxis/anmeldungen/([^/]+)/pdf', pfad)
        if m_pdf:
            pid, p = self._praxis_api()
            if not pid:
                return
            return self.pdf_liefern(pid, m_pdf.group(1))
        if pfad == '/portal':
            return self.portal(q)
        m_pdf = re.fullmatch(r'/portal/pdf/([^/]+)', pfad)
        if m_pdf:
            pid, p = self._praxis_portal()
            if pid:
                return self.pdf_liefern(pid, m_pdf.group(1), anzeigen=True)
            return
        self._send(404, 'Nicht gefunden')

    def do_OPTIONS(self):
        if urlparse(self.path).path == '/api/v1/praxis/messungen':
            return self._send(204, '', extra=CORS)
        self._send(404, 'Nicht gefunden')

    def do_POST(self):
        pfad = urlparse(self.path).path
        if pfad == '/api/v1/link':
            return self.link_anfordern()
        if pfad == '/api/v1/praxis/messungen':
            return self.messung_annehmen()
        m = re.fullmatch(r'/api/v1/f/([^/]+)/absenden', pfad)
        if m:
            return self.absenden(m.group(1))
        m = re.fullmatch(r'/api/v1/praxis/anmeldungen/([^/]+)/abgeholt', pfad)
        if m:
            pid, p = self._praxis_api()
            if not pid:
                return
            self._body_json()
            ok = self.ablage.abgeholt(pid, m.group(1))
            return self._send(204, '') if ok else self._json({'fehler': 'unbekannt'}, 404)
        if pfad == '/portal/link':
            pid, p = self._praxis_portal()
            if not pid:
                return
            n = int(self.headers.get('Content-Length') or 0)
            form = parse_qs(self.rfile.read(n).decode('utf-8'))
            email = (form.get('email') or [''])[0].strip()
            if not EMAIL_RE.fullmatch(email):
                return self._send(400, 'Ungültige E-Mail-Adresse')
            self.link_senden(pid, p, email)
            return self._send(303, '', extra={'Location': '/portal?gesendet=1'})
        self._send(404, 'Nicht gefunden')

    # Patient: Link anfordern
    def link_anfordern(self):
        d = self._body_json(10_000) or {}
        email = str(d.get('email', '')).strip()
        pid = str(d.get('praxis', ''))
        praxen = self.ablage.praxen()
        if pid not in praxen or not EMAIL_RE.fullmatch(email):
            return self._json({'fehler': 'Praxis oder E-Mail-Adresse ungültig'}, 400)
        url = self.link_senden(pid, praxen[pid], email)
        antwort = {'ok': True, 'hinweis': 'Wenn die Adresse stimmt, ist der Link unterwegs.'}
        if self.demo:
            antwort['demo_link'] = url
        self._json(antwort)

    def link_senden(self, pid, praxis, email):
        token = self.ablage.link_anlegen(pid, email)
        url = '%s/f/%s' % (self.basis_url, token)
        self.ablage.mail(email, 'Ihr Anmeldebogen – ' + praxis['name'],
                         'Guten Tag,\n\nhier ist Ihr persönlicher Link zum Anmeldebogen von %s:\n\n%s\n\n'
                         'Der Link ist %d Tage gültig und nur für Sie bestimmt. Sie können den Bogen jederzeit unterbrechen und später fortsetzen.\n\n'
                         'Freundliche Grüße\n%s' % (praxis['name'], url, LINK_TAGE, praxis['name']))
        print('Link erzeugt:', url)
        return url

    # Patient: Formular
    def formular(self, token):
        ln = self.ablage.link(token)
        if not ln:
            return self._send(404, seite('Link ungültig', '<p>Dieser Link ist nicht bekannt. Bitte fordern Sie auf der Website der Praxis einen neuen Link an.</p>'))
        if ln['verbraucht']:
            return self._send(410, seite('Bereits abgeschickt', '<p>Diese Anmeldung wurde bereits übermittelt. Vielen Dank.</p>'))
        if ln['gueltig_bis'] < jetzt():
            return self._send(410, seite('Link abgelaufen', '<p>Der Link ist abgelaufen. Bitte fordern Sie auf der Website der Praxis einen neuen Link an.</p>'))
        praxis = self.ablage.praxen()[ln['praxis']]['name']
        if self.formular_html:
            test = 'true' if parse_qs(urlparse(self.path).query).get('test') else 'false'
            seite_html = self.formular_html.replace('[NAME DER PRAXIS]', html.escape(praxis)).replace(
                '<script>\nclass Component', '<script>window.AMB={testMode:%s,email:%s};</script>\n<script>\nclass Component' % (test, json.dumps(ln['email'])), 1)
            return self._send(200, seite_html)
        self._send(200, SEITE_FORMULAR.replace('{{praxis}}', html.escape(praxis)).replace('{{token}}', token))

    def absenden(self, token):
        ln = self.ablage.link(token)
        if not ln or ln['verbraucht'] or ln['gueltig_bis'] < jetzt():
            return self._json({'fehler': 'Link ungültig oder abgelaufen'}, 410)
        daten = self._body_json()
        fehler = pruefe_anmeldung(daten)
        if fehler:
            return self._json({'fehler': fehler}, 400)
        praxis = self.ablage.praxen()[ln['praxis']]
        daten['druck']['praxis'] = praxis['name']
        daten.setdefault('erstellt', jetzt())
        try:
            pdf = pdf_uebersicht.build_bytes(daten)
        except Exception as e:
            return self._json({'fehler': 'PDF konnte nicht erzeugt werden: %s' % e}, 500)
        name = pdf_uebersicht.dateiname(daten)
        with self.ablage.sperre:
            aid = self.ablage.anmeldung_speichern(ln['praxis'], daten, pdf, name)
            self.ablage.link_verbrauchen(token)
        self.ablage.mail(praxis['email'], 'Neue Anmeldung: ' + kurzname(daten),
                         'Eine neue Anmeldung ist eingegangen (%s). Sie wird vom AMB+-Connector automatisch in den THEORG-Importordner übertragen '
                         'oder kann im Praxisportal heruntergeladen werden.' % kurzname(daten))
        self.ablage.aufraeumen()
        print('Anmeldung gespeichert:', aid, name)
        self._json({'ok': True})

    # Therapeut: Goniometer
    def goniometer(self):
        if not self.goniometer_html:
            return self._send(404, 'Nicht gefunden')
        seite_html = self.goniometer_html
        if self.demo:  # Vorführung: Geräte-Schlüssel ist schon eingetragen
            p = next(iter(self.ablage.praxen().values()))
            seite_html = seite_html.replace('<head>', '<head>\n<script>window.AMB_GONIO=%s;</script>' % json.dumps(
                {'schluessel': p['geraete_schluessel']}), 1)
        self._send(200, seite_html)

    def messung_annehmen(self):
        auth = self.headers.get('Authorization', '')
        pid, praxis = self.ablage.praxis_per_geraeteschluessel(auth[7:] if auth.startswith('Bearer ') else '')
        if not pid:
            return self._json({'fehler': 'nicht berechtigt'}, 401, CORS)
        daten = self._body_json(200_000)
        fehler = pruefe_messung(daten)
        if fehler:
            return self._json({'fehler': fehler}, 400, CORS)
        daten['praxis'] = praxis['name']
        daten['erstellt'] = dt.datetime.now().isoformat(timespec='seconds')
        try:
            pdf = pdf_goniometer.build_bytes(daten)
        except Exception as e:
            return self._json({'fehler': 'PDF konnte nicht erzeugt werden: %s' % e}, 500, CORS)
        name = pdf_goniometer.dateiname(daten)
        with self.ablage.sperre:
            aid = self.ablage.anmeldung_speichern(pid, daten, pdf, name, art='Goniometer')
        self.ablage.aufraeumen()
        print('Messung gespeichert:', aid, name)
        self._json({'ok': True}, 200, CORS)


    # Demo: Übersichtsseite für die Vorführung
    def demo_seite(self):
        praxen = self.ablage.praxen()
        pid, p = next(iter(praxen.items()))
        mails = sorted(os.listdir(os.path.join(self.ablage.wurzel, 'outbox')), reverse=True)[:6]
        mail_html = ''
        for m in mails:
            with open(os.path.join(self.ablage.wurzel, 'outbox', m), encoding='utf-8') as f:
                t = f.read()
            t = html.escape(t)
            t = re.sub(r'(https?://[^\s<]+)', r'<a href="\1" target="_blank">\1</a>', t)
            mail_html += '<pre class="mail">%s</pre>' % t
        anm = self.ablage.anmeldungen(pid)
        inhalt = DEMO_SEITE.format(
            start=html.escape(self.basis_url + '/'), praxis=html.escape(p['name']), kennung=html.escape(pid),
            schluessel=html.escape(p['schluessel']), importordner=html.escape(self.demo_import or '(nicht gesetzt)'),
            anzahl=len(anm), neu=sum(1 for a in anm if a['status'] == 'neu'),
            mails=mail_html or '<p class="hint">Noch keine E-Mails. Fordern Sie oben einen Link an.</p>')
        self._send(200, seite('AMB+ – Vorführung', inhalt))

    # Praxis: PDF
    def pdf_liefern(self, pid, aid, anzeigen=False):
        m = self.ablage.meta(pid, aid)
        if not m:
            return self._json({'fehler': 'unbekannt'}, 404)
        with open(self.ablage.pdf_pfad(aid), 'rb') as f:
            b = f.read()
        self._send(200, b, 'application/pdf', {'Content-Disposition': '%s; filename="%s"' % ('inline' if anzeigen else 'attachment', m['dateiname'])})

    # Praxis: Portal
    def portal(self, q):
        pid, p = self._praxis_portal()
        if not pid:
            return
        zeilen = []
        for m in reversed(self.ablage.anmeldungen(pid)):
            zeilen.append('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href="/portal/pdf/%s" target="_blank">PDF</a></td></tr>' % (
                html.escape(m['eingang'][:16].replace('T', ' ')), html.escape(m.get('art', 'Anmeldung')), html.escape(m['patient_kurz']),
                'neu' if m['status'] == 'neu' else 'abgeholt', m['id']))
        hinweis = '<p class="ok">Link wurde erzeugt und per E-Mail verschickt.</p>' if q.get('gesendet') else ''
        gonio_link = html.escape('%s/goniometer/#schluessel=%s' % (self.basis_url, p['geraete_schluessel']))
        body = SEITE_PORTAL.replace('{{praxis}}', html.escape(p['name'])).replace('{{zeilen}}', ''.join(zeilen) or '<tr><td colspan="5">Noch keine Anmeldungen.</td></tr>').replace(
            '{{hinweis}}', hinweis).replace('{{gonio_link}}', gonio_link)
        self._send(200, body)


EMAIL_RE = re.compile(r'[^@\s]+@[^@\s]+\.[^@\s]+')

STIL = '<style>body{font-family:system-ui,sans-serif;max-width:720px;margin:40px auto;padding:0 16px;color:#1B2624}h1{font-size:22px}.btn{display:inline-block;background:#0F6B5C;color:#fff;padding:12px 20px;border-radius:8px;border:0;font-size:16px;cursor:pointer}input{padding:10px;font-size:16px;border:1px solid #CBD5D1;border-radius:8px;width:100%;max-width:360px}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:8px;border-bottom:1px solid #E7ECEA}.ok{color:#2E9E5B}.hint{color:#5B6864;font-size:14px}</style>'


def seite(titel, inhalt):
    return '<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>%s</title>%s<body><h1>%s</h1>%s</body></html>' % (titel, STIL, titel, inhalt)


SEITE_START = seite('Anmeldebogen anfordern', '''
<p>So sieht das Feld auf der Praxis-Website aus: Der Patient gibt seine E-Mail-Adresse ein und bekommt den persönlichen Link.</p>
<form onsubmit="return senden(event)"><p><input id="email" type="email" placeholder="Ihre E-Mail-Adresse" required></p>
<p><button class="btn">Anmeldebogen per E-Mail erhalten</button></p></form><p id="aw" class="hint"></p>
<script>async function senden(e){e.preventDefault();const r=await fetch('/api/v1/link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({praxis:'testpraxis',email:document.getElementById('email').value})});const j=await r.json();const aw=document.getElementById('aw');aw.textContent=j.hinweis||j.fehler;if(j.demo_link){const p=document.createElement('p');p.innerHTML='<b>Demo:</b> Statt der E-Mail hier direkt der Link: ';const a=document.createElement('a');a.href=j.demo_link;a.textContent='Anmeldebogen öffnen';p.appendChild(a);aw.appendChild(p)}return false}</script>''')

SEITE_FORMULAR = seite('Anmeldung bei {{praxis}}', '''
<p>Hier wird später der Anmeldebogen angezeigt. Im Prototyp können Sie eine Beispielanmeldung (Max Mustermann) absenden, um den Ablauf zu prüfen.</p>
<p><button class="btn" onclick="absenden()">Beispielanmeldung absenden</button></p><p id="aw" class="hint"></p>
<script>async function absenden(){const b=await (await fetch('/beispiel.json')).json();const r=await fetch('/api/v1/f/{{token}}/absenden',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});const j=await r.json();document.getElementById('aw').textContent=j.ok?'Ihre Anmeldung ist bei der Praxis eingegangen. Vielen Dank.':j.fehler}</script>''')

SEITE_PORTAL = seite('Praxisportal – {{praxis}}', '''{{hinweis}}
<h2>Link an Patienten senden</h2><form method="post" action="/portal/link"><p><input name="email" type="email" placeholder="E-Mail-Adresse des Patienten" required></p><p><button class="btn">Link senden</button></p></form>
<h2>Anmeldungen und Messungen</h2><table><tr><th>Eingang</th><th>Art</th><th>Patient</th><th>Status</th><th></th></tr>{{zeilen}}</table>
<p class="hint">Neue Einträge holt der AMB+-Connector automatisch in den THEORG-Importordner. Abgeholte Einträge werden nach 30 Tagen gelöscht, alle spätestens nach 90 Tagen.</p>
<h2>Goniometer einrichten</h2>
<p>Diesen Link einmal auf dem Handy oder Tablet öffnen, mit dem gemessen wird. Er trägt den Geräte-Schlüssel ein; danach landen Messungen über „In E-Akte speichern“ hier und im THEORG-Importordner.</p>
<p><a href="{{gonio_link}}" target="_blank" style="word-break:break-all">{{gonio_link}}</a></p>
<p class="hint">Der Geräte-Schlüssel erlaubt nur das Senden von Messungen, nicht das Lesen von Anmeldungen. Die Bewegungssensoren des Handys funktionieren nur, wenn der Server über HTTPS erreichbar ist.</p>''')

CORS = {'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Max-Age': '600'}


DEMO_SEITE = """
<style>.schritt{{border:1px solid #CBD5D1;border-radius:12px;padding:14px 18px;margin:14px 0}}.schritt h2{{font-size:17px;margin:0 0 6px}}.mail{{white-space:pre-wrap;background:#F6F7F4;border:1px solid #CBD5D1;border-radius:8px;padding:10px;font-size:13px}}code{{background:#F6F7F4;padding:2px 6px;border-radius:4px}}</style>
<p class="hint">Diese Seite gibt es nur im Demo-Modus. Sie zeigt alles, was im echten Betrieb per E-Mail oder im Hintergrund passiert. Seite neu laden, um den aktuellen Stand zu sehen.</p>
<div class="schritt"><h2>1. Patient fordert den Bogen an</h2>
<p>So sieht das Feld auf der Praxis-Website aus: <a href="/" target="_blank">Anmeldebogen anfordern</a></p>
<p>Am <b>Handy</b> (im selben WLAN) diese Adresse öffnen: <code>{start}</code></p></div>
<div class="schritt"><h2>2. Patient füllt aus und sendet ab</h2>
<p>Der Link aus der E-Mail führt zum Bogen. Zum schnellen Durchklicken ohne Pflichtfelder <code>?test=1</code> an den Link hängen.</p></div>
<div class="schritt"><h2>3. Praxis erhält die Anmeldung</h2>
<p>Eingänge bisher (Anmeldungen und Messungen): <b>{anzahl}</b>, davon noch nicht abgeholt: <b>{neu}</b>.</p>
<p>Der Connector legt das PDF automatisch (alle 15 Sekunden) hier ab:<br><code>{importordner}</code></p>
<p>In THEORG: Patient öffnen → E-Akte → Blitzimport.</p></div>
<div class="schritt"><h2>4. Praxisportal</h2>
<p><a href="/portal" target="_blank">Praxisportal öffnen</a> – Benutzer <code>{kennung}</code>, Passwort <code>{schluessel}</code></p>
<p class="hint">Dort sieht die Rezeption alle Anmeldungen, öffnet das PDF und kann Patienten einen Link schicken.</p></div>
<div class="schritt"><h2>5. Goniometer: Therapeut misst</h2>
<p><a href="/goniometer/" target="_blank">Goniometer öffnen</a> – am Handy: <code>{start}goniometer/</code></p>
<p>Patient eingeben, Gelenke messen, „In E-Akte speichern“. Das Messprotokoll landet wie eine Anmeldung als PDF im Importordner (<code>…_Goniometer_….pdf</code>). Der Geräte-Schlüssel ist in der Demo schon eingetragen.</p>
<p class="hint">Die Bewegungssensoren des Handys funktionieren nur über HTTPS. In der Demo (HTTP im WLAN) daher die Werte von Hand eintippen; im echten Betrieb mit HTTPS misst das Handy selbst.</p></div>
<h2>E-Mails (im echten Betrieb verschickt)</h2>
{mails}
"""


class HandlerMitBeispiel(Handler):
    beispiel = None

    def do_GET(self):
        if urlparse(self.path).path == '/beispiel.json' and self.beispiel:
            return self._send(200, self.beispiel, 'application/json; charset=utf-8')
        super().do_GET()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8080)
    ap.add_argument('--data', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data'))
    ap.add_argument('--basis-url', default=None, help='öffentliche Adresse, z. B. https://app.amb-plus.de')
    ap.add_argument('--demo', action='store_true', help='Demo-Modus für Vorführungen')
    ap.add_argument('--demo-import', default='', help='Importordner, der auf der Demo-Seite angezeigt wird')
    ap.add_argument('--formular', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'web', 'anmeldung.html'))
    ap.add_argument('--beispiel', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'beispiel-anmeldung.json'))
    ap.add_argument('--goniometer', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'goniometer', 'index.html'))
    a = ap.parse_args()
    HandlerMitBeispiel.ablage = Ablage(a.data)
    HandlerMitBeispiel.basis_url = a.basis_url or 'http://%s:%d' % (lan_ip(), a.port)
    HandlerMitBeispiel.demo = a.demo
    HandlerMitBeispiel.demo_import = a.demo_import
    if os.path.exists(a.formular):
        with open(a.formular, encoding='utf-8') as f:
            HandlerMitBeispiel.formular_html = f.read()
        print('Formular:', os.path.abspath(a.formular))
    else:
        print('Hinweis: web/anmeldung.html nicht gefunden – Formularseite zeigt nur die Beispielanmeldung.')
    if os.path.exists(a.goniometer):
        with open(a.goniometer, encoding='utf-8') as f:
            HandlerMitBeispiel.goniometer_html = f.read()
        print('Goniometer:', os.path.abspath(a.goniometer))
    if os.path.exists(a.beispiel):
        with open(a.beispiel, encoding='utf-8') as f:
            HandlerMitBeispiel.beispiel = f.read()
    praxen = HandlerMitBeispiel.ablage.praxen()
    print('AMB+-Server auf %s, Daten in %s' % (HandlerMitBeispiel.basis_url, a.data))
    for pid, p in praxen.items():
        print('Praxis %s (%s) – Schlüssel: %s – Geräte-Schlüssel (Goniometer): %s' % (pid, p['name'], p['schluessel'], p['geraete_schluessel']))
    ThreadingHTTPServer(('0.0.0.0', a.port), HandlerMitBeispiel).serve_forever()


if __name__ == '__main__':
    main()
