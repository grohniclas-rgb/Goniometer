#!/usr/bin/env python3
"""AMB+ – Praxis-Übersicht als A4-PDF erzeugen.

Läuft im Hintergrund auf dem Server, sobald ein Patient die Anmeldung abschließt.
Eingabe: die Exportdatei des Formulars (Schema amb-plus/anmeldung, ab Version 0.2),
         daraus wird nur der Abschnitt "druck" gelesen.
Ausgabe: druckfertiges PDF (A4, Seitenzahlen, Körperschema mit markierten Regionen).

Aufruf:  python3 pdf_uebersicht.py anmeldung.json uebersicht.pdf
         python3 pdf_uebersicht.py anmeldung.json C:\\THEORG\\IMPORT\\
         (Ist das Ziel ein Ordner, wird der Dateiname automatisch gebildet:
          Nachname_Vorname_TT.MM.JJJJ_Anmeldung_JJJJ-MM-TT.pdf – so findet die Praxis
          die Datei z. B. beim THEORG-Blitzimport sofort beim richtigen Patienten.)
"""
import colorsys
import json
import os
import re
import sys

from reportlab.graphics.shapes import Circle, Drawing, Ellipse, Line, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

# ---------- Schrift (Umlaute, „“, →, ≥). Für den Server die TTF-Dateien mitliefern.
FONT_DIRS = [os.path.join(os.path.dirname(__file__), 'fonts'),
             '/usr/share/fonts/truetype/liberation', '/usr/share/fonts/truetype/dejavu']
FONT_CANDIDATES = [('LiberationSans-Regular.ttf', 'LiberationSans-Bold.ttf'),
                   ('DejaVuSans.ttf', 'DejaVuSans-Bold.ttf')]


def register_fonts():
    for reg, bold in FONT_CANDIDATES:
        for d in FONT_DIRS:
            if os.path.exists(os.path.join(d, reg)) and os.path.exists(os.path.join(d, bold)):
                pdfmetrics.registerFont(TTFont('AMB', os.path.join(d, reg)))
                pdfmetrics.registerFont(TTFont('AMB-Bold', os.path.join(d, bold)))
                pdfmetrics.registerFontFamily('AMB', normal='AMB', bold='AMB-Bold')
                return 'AMB', 'AMB-Bold'
    return 'Helvetica', 'Helvetica-Bold'


FONT, FONT_B = register_fonts()

INK = colors.HexColor('#1B2624')
MUTED = colors.HexColor('#5B6864')
ACCENT = colors.HexColor('#0F6B5C')
LINE = colors.HexColor('#CBD5D1')
BODY_FILL = colors.HexColor('#E6EBE8')
BODY_STROKE = colors.HexColor('#AEBBB6')
MARK_FILL = colors.Color(0.84, 0.27, 0.27, alpha=0.65)
MARK_STROKE = colors.HexColor('#B3261E')
NAMED = {'rot': '#C62828', 'gelb': '#E0A100', 'gruen': '#2E9E5B', 'grau': '#9AA5A1'}


def to_color(v):
    """Farbe aus dem Export: Name, #hex oder hsl(h,s%,l%)."""
    if not v:
        return None
    if v in NAMED:
        return colors.HexColor(NAMED[v])
    if v.startswith('#'):
        return colors.HexColor(v)
    m = re.match(r'hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)', v)
    if m:
        h, s, l = (int(g) for g in m.groups())
        r, g, b = colorsys.hls_to_rgb(h / 360, l / 100, s / 100)
        return colors.Color(r, g, b)
    return None


ST_KEY = ParagraphStyle('k', fontName=FONT, fontSize=7.8, leading=9.4, textColor=MUTED, alignment=TA_LEFT)
ST_VAL = ParagraphStyle('v', fontName=FONT, fontSize=8.4, leading=10.2, textColor=INK)
ST_VAL_B = ParagraphStyle('vb', parent=ST_VAL, fontName=FONT_B)
ST_HEAD = ParagraphStyle('h', fontName=FONT_B, fontSize=8.4, leading=10, textColor=ACCENT)
ST_TITLE = ParagraphStyle('t', fontName=FONT_B, fontSize=15, leading=18, textColor=INK)
ST_SMALL = ParagraphStyle('s', fontName=FONT, fontSize=8, leading=10, textColor=MUTED)


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))


class Dot:
    """Farbpunkt der Ampel als Tabellenzelle."""

    def __init__(self, col):
        self.col = col

    def drawing(self):
        d = Drawing(4 * mm, 3.4 * mm)
        if self.col is not None:
            d.add(Circle(1.7 * mm, 1.5 * mm, 1.55 * mm, fillColor=self.col, strokeColor=None))
        return d


# ---------- Körperschema: gleiche Formen wie im Formular (150 x 330 Einheiten, y nach unten)
def _front_back(g, back=False):
    shapes = [('c', 75, 28, 20), ('r', 66, 44, 18, 16, 4), ('r', 38, 58, 74, 118, 20),
              ('r', 16, 64, 20, 112, 10), ('r', 114, 64, 20, 112, 10),
              ('e', 25, 186, 10, 12), ('e', 125, 186, 10, 12),
              ('r', 45, 168, 28, 138, 13), ('r', 77, 168, 28, 138, 13),
              ('e', 58, 313, 15, 8), ('e', 92, 313, 15, 8)]
    if back:
        shapes.append(('l', 75, 62, 75, 150))
    return shapes


def _side(left=False):
    if not left:
        return [('c', 75, 28, 20), ('e', 57, 31, 4, 5), ('r', 68, 44, 16, 16, 4), ('r', 54, 58, 44, 118, 18),
                ('r', 60, 168, 30, 138, 13), ('e', 84, 313, 22, 8),
                ('r2', 67, 64, 18, 108, 9), ('e2', 76, 181, 9, 11)]
    return [('c', 75, 28, 20), ('e', 93, 31, 4, 5), ('r', 66, 44, 16, 16, 4), ('r', 52, 58, 44, 118, 18),
            ('r', 60, 168, 30, 138, 13), ('e', 66, 313, 22, 8),
            ('r2', 65, 64, 18, 108, 9), ('e2', 74, 181, 9, 11)]


SHAPES = {'front': _front_back(None), 'back': _front_back(None, True), 'right': _side(), 'left': _side(True)}
SIDE_LABELS = {'front': ('R', 'L'), 'back': ('L', 'R')}


def body_map(koerper, scale=0.5, gap=10 * mm):
    """Vier Ansichten nebeneinander, markierte Regionen rot."""
    W, H = 150 * scale, 330 * scale
    total_w = 4 * W + 3 * gap
    d = Drawing(total_w, H + 14)
    views = {v['ansicht']: v for v in koerper}
    for i, key in enumerate(['front', 'back', 'right', 'left']):
        ox = i * (W + gap)
        oy = 0
        Y = lambda y: oy + H - y * scale  # noqa: E731  (Formular-Koordinaten nach PDF)
        for sh in SHAPES[key]:
            t = sh[0]
            fill = colors.HexColor('#D9E0DC') if t.endswith('2') else BODY_FILL
            if t == 'c':
                d.add(Circle(ox + sh[1] * scale, Y(sh[2]), sh[3] * scale, fillColor=fill, strokeColor=BODY_STROKE, strokeWidth=0.7))
            elif t in ('e', 'e2'):
                d.add(Ellipse(ox + sh[1] * scale, Y(sh[2]), sh[3] * scale, sh[4] * scale, fillColor=fill, strokeColor=BODY_STROKE, strokeWidth=0.7))
            elif t in ('r', 'r2'):
                x, y, w, h, rr = sh[1:]
                d.add(Rect(ox + x * scale, Y(y + h), w * scale, h * scale, rx=rr * scale, ry=rr * scale,
                           fillColor=fill, strokeColor=BODY_STROKE, strokeWidth=0.7))
            elif t == 'l':
                d.add(Line(ox + sh[1] * scale, Y(sh[2]), ox + sh[3] * scale, Y(sh[4]), strokeColor=BODY_STROKE,
                           strokeWidth=0.7, strokeDashArray=[2, 2]))
        for r in views.get(key, {}).get('regionen', []):
            d.add(Rect(ox + r['x'] * scale, Y(r['y'] + r['h']), r['w'] * scale, r['h'] * scale, rx=3, ry=3,
                       fillColor=MARK_FILL, strokeColor=MARK_STROKE, strokeWidth=1))
        if key in SIDE_LABELS:
            l, rgt = SIDE_LABELS[key]
            d.add(String(ox + 2, Y(10), l, fontName=FONT_B, fontSize=7, fillColor=MUTED))
            d.add(String(ox + W - 6, Y(10), rgt, fontName=FONT_B, fontSize=7, fillColor=MUTED))
        name = views.get(key, {}).get('name') or {'front': 'Vorne', 'back': 'Hinten', 'right': 'Seite rechts', 'left': 'Seite links'}[key]
        d.add(String(ox + W / 2, H + 4, name, fontName=FONT_B, fontSize=6.5, fillColor=INK, textAnchor='middle'))
    return d


def section_table(rows, avail, key_w=46 * mm, title=None):
    """Abschnitt als Tabelle: optional Überschrift, dann Ampelpunkt | Frage | Antwort."""
    data, style = [], [
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 0.8), ('BOTTOMPADDING', (0, 0), (-1, -1), 0.8),
    ]
    start = 0
    if title:
        data.append([Paragraph(esc(title).upper(), ST_HEAD), '', ''])
        style += [('SPAN', (0, 0), (-1, 0)), ('LINEBELOW', (0, 0), (-1, 0), 0.5, LINE), ('BOTTOMPADDING', (0, 0), (-1, 0), 2)]
        start = 1
    for r in rows:
        col = to_color(r.get('farbe'))
        val = Paragraph(esc(r.get('v', '')), ST_VAL_B if r.get('fett') else ST_VAL)
        data.append([Dot(col).drawing(), Paragraph(esc(r.get('k', '')), ST_KEY), val])
    if len(data) > start + 1:
        style.append(('LINEBELOW', (0, start), (-1, -2), 0.25, colors.HexColor('#E7ECEA')))
    t = Table(data, colWidths=[4.2 * mm, key_w, avail - 4.2 * mm - key_w], repeatRows=1 if title else 0)
    t.setStyle(TableStyle(style))
    return t


# Abschnitte über die volle Breite; alle anderen werden paarweise nebeneinander gesetzt
WIDE = ('Ampel', 'Red Flags', 'Verordnung und Beschwerden', 'Anlass und Schmerz')
SKIP_ROWS = {('Patient', 'Name')}  # steht schon im Titel


def build(data, out_path):
    druck = data.get('druck') or {}
    praxis = druck.get('praxis') or ''
    erstellt = druck.get('erstellt') or ''
    hinweis = druck.get('hinweis') or ''

    doc = SimpleDocTemplate(out_path, pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=12 * mm, bottomMargin=15 * mm,
                            title='Anmeldung – ' + (druck.get('titel') or ''), author=praxis)
    avail = A4[0] - doc.leftMargin - doc.rightMargin

    story = [Paragraph(esc(praxis) + ' · Anmeldung und Anamnese · erstellt am ' + esc(erstellt), ST_SMALL),
             Spacer(1, 2), Paragraph(esc(druck.get('titel') or ''), ST_TITLE), Spacer(1, 2)]
    hr = Table([['']], colWidths=[avail], rowHeights=[1])
    hr.setStyle(TableStyle([('LINEBELOW', (0, 0), (-1, -1), 1.2, INK)]))
    story.append(hr)

    # Zeilen in Abschnitte gruppieren
    sections, cur = [], None
    for z in druck.get('zeilen', []):
        if z.get('typ') == 'kopf':
            cur = {'titel': z.get('text', ''), 'rows': []}
            sections.append(cur)
        elif cur is not None:
            cur['rows'].append(z)

    koerper = druck.get('koerper')
    half = (avail - 6 * mm) / 2
    group = []  # aufeinanderfolgende schmale Abschnitte -> zweispaltig, ausgeglichen, seitenübergreifend

    def flush():
        """Schmale Abschnitte in zwei Spalten: links von oben auffüllen bis zur Hälfte, Rest rechts."""
        if not group:
            return
        blocks = []
        for g in group:
            hd = Table([[Paragraph(esc(g['titel']).upper(), ST_HEAD)]], colWidths=[half])
            hd.setStyle(TableStyle([('LEFTPADDING', (0, 0), (-1, -1), 0), ('TOPPADDING', (0, 0), (-1, -1), 0),
                                    ('BOTTOMPADDING', (0, 0), (-1, -1), 2), ('LINEBELOW', (0, 0), (-1, -1), 0.5, LINE)]))
            tb = section_table(g['rows'], half, 30 * mm)
            h = hd.wrap(half, 9999)[1] + tb.wrap(half, 9999)[1] + 6
            blocks.append(([hd, tb, Spacer(1, 6)], h))
        total = sum(h for _, h in blocks)
        # Abschnitte so auf zwei Spalten verteilen, dass beide möglichst gleich hoch sind
        # (größte zuerst in die kürzere Spalte; innerhalb einer Spalte bleibt die Fragebogen-Reihenfolge)
        cols, hs = [[], []], [0, 0]
        for idx in sorted(range(len(blocks)), key=lambda n: -blocks[n][1]):
            c = 0 if hs[0] <= hs[1] else 1
            cols[c].append(idx)
            hs[c] += blocks[idx][1]
        if cols[0] and cols[1] and min(cols[1]) < min(cols[0]):
            cols.reverse()
            hs.reverse()
        left = [f for n in sorted(cols[0]) for f in blocks[n][0]]
        right = [f for n in sorted(cols[1]) for f in blocks[n][0]]
        acc = hs[0]
        story.append(Spacer(1, 5))
        if max(acc, total - acc) > 700:  # zu hoch für eine Seite: einspaltig, damit umgebrochen werden kann
            story.extend(left + right)
        else:
            t = Table([[left, right]], colWidths=[half + 6 * mm, half])
            t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 0),
                                   ('RIGHTPADDING', (0, 0), (-1, -1), 0), ('TOPPADDING', (0, 0), (-1, -1), 0),
                                   ('BOTTOMPADDING', (0, 0), (-1, -1), 0)]))
            story.append(t)
        group.clear()

    for sec in sections:
        sec['rows'] = [r for r in sec['rows'] if (sec['titel'], r.get('k')) not in SKIP_ROWS]
        if not sec['rows']:
            continue
        if not sec['titel'].startswith(WIDE):
            group.append(sec)
            continue
        flush()
        story.append(Spacer(1, 5))
        if koerper and sec['titel'].startswith('Anlass und Schmerz'):
            bm = body_map(koerper, scale=0.36, gap=4 * mm)
            left_w = avail - bm.width - 5 * mm
            t = Table([[section_table(sec['rows'], left_w, 34 * mm, sec['titel']), bm]],
                      colWidths=[left_w + 5 * mm, bm.width])
            t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 0),
                                   ('RIGHTPADDING', (0, 0), (-1, -1), 0), ('TOPPADDING', (1, 0), (1, 0), 14)]))
            story.append(t)
        else:
            story.append(section_table(sec['rows'], avail, 46 * mm, sec['titel']))
    flush()

    def on_page(canv, d):
        canv.saveState()
        canv.setFont(FONT, 7.5)
        canv.setFillColor(MUTED)
        canv.drawString(doc.leftMargin, 8 * mm, hinweis)
        canv.drawRightString(A4[0] - doc.rightMargin, 8 * mm, 'Seite %d' % d.page)
        canv.restoreState()

    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)


def build_bytes(data):
    """PDF als Bytes (für den Server)."""
    import io
    buf = io.BytesIO()
    build(data, buf)
    return buf.getvalue()


def dateiname(data):
    """Sprechender, eindeutiger Dateiname für die Ablage beim Patienten."""
    p = data.get('patient') or {}
    gd = p.get('geburtsdatum') or ''
    gd = '.'.join(reversed(gd.split('-'))) if gd else 'ohne-Geburtsdatum'
    teile = [p.get('nachname') or 'Unbekannt', p.get('vorname') or '', gd, 'Anmeldung', (data.get('erstellt') or '')[:10]]
    name = '_'.join(t for t in teile if t)
    return re.sub(r'[^0-9A-Za-zÄÖÜäöüß._-]+', '-', name) + '.pdf'


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    with open(sys.argv[1], encoding='utf-8') as fh:
        daten = json.load(fh)
    ziel = sys.argv[2]
    if os.path.isdir(ziel) or ziel.endswith(('/', '\\')):
        os.makedirs(ziel, exist_ok=True)
        ziel = os.path.join(ziel, dateiname(daten))
    build(daten, ziel)
    print('PDF erstellt:', ziel)
