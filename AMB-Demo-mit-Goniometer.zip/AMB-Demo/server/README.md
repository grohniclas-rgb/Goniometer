# AMB+-Server (Prototyp)

Nimmt Anmeldungen entgegen, erzeugt das Praxis-PDF und stellt es dem Connector und dem Praxisportal bereit.

## Dateien
- `amb_server.py` – Server (Python 3, Standardbibliothek)
- `pdf_uebersicht.py` – PDF-Erzeugung (braucht `reportlab`: `pip install reportlab`)
- `beispiel-anmeldung.json` – Beispiel-Exportdatei (Max Mustermann), wird im Prototyp auf der Formularseite abgesendet
- `data/` – entsteht beim Start: `praxen.json` (Praxen und Schlüssel), `links/`, `anmeldungen/`, `outbox/` (E-Mails als Textdateien)

## Start (lokal)
```
python3 amb_server.py --port 8080
```
Beim ersten Start wird die Praxis `testpraxis` mit einem zufälligen Praxis-Schlüssel angelegt; der Schlüssel steht in der Konsole und in `data/praxen.json`. Weitere Praxen: Eintrag in `praxen.json` ergänzen (`name`, `schluessel`, `email`).

## Durchspielen
1. `http://127.0.0.1:8080/` – Feld „Anmeldebogen per E-Mail erhalten“ (wie auf der Praxis-Website). Die E-Mail liegt danach in `data/outbox/`.
2. Link aus der E-Mail öffnen → Formularseite → „Beispielanmeldung absenden“.
3. Der Server erzeugt das PDF und legt eine Benachrichtigung für die Praxis in `data/outbox/`.
4. Connector (`../connector/amb_connector.py`) mit `server = http://127.0.0.1:8080` und dem Praxis-Schlüssel starten → PDF landet im Importordner.
5. Praxisportal: `http://127.0.0.1:8080/portal`, Anmeldung mit Benutzer `testpraxis` und dem Praxis-Schlüssel als Passwort. Liste, PDF-Ansicht, Link an Patienten senden.

## Goniometer
- `../goniometer/index.html` ist eine eigene App für Therapeuten; der Server liefert sie unter `/goniometer/` aus. Sie kann auch woanders liegen (z. B. GitHub Pages), dann im Goniometer unter „AMB+-Verbindung“ die Server-Adresse eintragen.
- `POST /api/v1/praxis/messungen` mit `Authorization: Bearer <Geräte-Schlüssel>`, JSON `amb-plus/goniometer` (Patient mit Name und Geburtsdatum, Messwerte 0–180°). Der Server erzeugt mit `pdf_goniometer.py` das Messprotokoll und legt es wie eine Anmeldung ab (Art „Goniometer“); der Connector holt es ohne Änderung ab.
- Geräte-Schlüssel: steht je Praxis in `praxen.json` (`geraete_schluessel`, wird beim Start ergänzt). Er erlaubt nur das Senden von Messungen, nicht das Lesen von Anmeldungen. Einrichtungslink fürs Handy im Praxisportal.
- Die Bewegungssensoren laufen nur über HTTPS; ohne Sensor gibt der Therapeut die Werte von Hand ein (im PDF mit * markiert).

## Regeln
- Link: 14 Tage gültig, einmal verwendbar, danach „bereits abgeschickt“.
- Anmeldungen: nach Abholung 30 Tage, spätestens nach 90 Tagen gelöscht; abgelaufene Links werden entfernt.
- Benachrichtigungen an Patient und Praxis enthalten keine Gesundheitsdaten.

## Für den echten Betrieb noch nötig
- HTTPS über einen Reverse Proxy (z. B. Caddy oder nginx), Server in Deutschland/EU.
- Echter E-Mail-Versand (SMTP eines deutschen Anbieters) statt `outbox/`.
- Verschlüsselte Ablage (Festplatten- oder Dateiverschlüsselung), Backups, Protokollierung.
- Das echte Formular auf der Seite `/f/<token>` einbinden; es sendet dieselbe Exportdatei (`amb-plus/anmeldung`) an `/api/v1/f/<token>/absenden`.
- Praxisportal: Schlüssel neu erzeugen/sperren, mehrere Benutzer, Einwilligungstexte.
