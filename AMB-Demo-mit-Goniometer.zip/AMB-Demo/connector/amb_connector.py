#!/usr/bin/env python3
"""AMB+-Connector – holt neue Anmeldungen (PDF) vom AMB+-Server ab und legt sie
im THEORG-Importordner ab.

Läuft auf dem THEORG-PC der Praxis. Braucht nur Python 3 (Standardbibliothek),
keine Zusatzpakete, nur ausgehende HTTPS-Verbindungen (keine Firewall-Freigabe).

Aufruf:
  python amb_connector.py                 Dauerbetrieb (prüft alle N Minuten)
  python amb_connector.py --once          einmal abholen und beenden (z. B. Aufgabenplanung)
  python amb_connector.py --test          Verbindung und Ordner prüfen, nichts abholen
  python amb_connector.py --config PFAD   andere Konfigurationsdatei

Konfiguration: amb_connector.ini neben dem Programm (siehe amb_connector.example.ini).

Ablauf je Durchlauf:
  1. GET  {server}/api/v1/praxis/anmeldungen?status=neu      -> Liste neuer Anmeldungen
  2. GET  {server}/api/v1/praxis/anmeldungen/{id}/pdf        -> PDF herunterladen
     -> Datei wird erst als *.part geschrieben, dann umbenannt (nie halbe PDFs im Ordner)
  3. POST {server}/api/v1/praxis/anmeldungen/{id}/abgeholt   -> Empfang bestätigen
     (erst nach erfolgreichem Speichern; Server markiert als abgeholt und löscht später)
  4. Dateien im Importordner, die älter als N Tage sind, nach "erledigt\" verschieben
Jeder Schritt wird protokolliert (amb_connector.log, ohne Gesundheitsdaten).
"""
import argparse
import configparser
import json
import logging
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.request
from logging.handlers import RotatingFileHandler

VERSION = '0.1'
HIER = os.path.dirname(os.path.abspath(__file__))
STANDARD_INI = os.path.join(HIER, 'amb_connector.ini')

STANDARD = {
    'server': 'https://app.amb-plus.de',
    'praxis_schluessel': '',
    'importordner': r'C:\THEORG\IMPORT',
    'intervall_minuten': '5',
    'aufraeumen_nach_tagen': '30',
    'erledigt_ordner': 'erledigt',
    'protokoll': os.path.join(HIER, 'amb_connector.log'),
}


# ---------- Konfiguration und Protokoll
def lade_konfig(pfad):
    cp = configparser.ConfigParser()
    cp['connector'] = dict(STANDARD)
    if os.path.exists(pfad):
        cp.read(pfad, encoding='utf-8')
    k = dict(cp['connector'])
    k['server'] = k['server'].rstrip('/')
    k['intervall_minuten'] = max(0.25, float(k['intervall_minuten']))
    k['aufraeumen_nach_tagen'] = int(k['aufraeumen_nach_tagen'])
    return k


def richte_protokoll_ein(pfad):
    log = logging.getLogger('amb')
    log.setLevel(logging.INFO)
    fmt = logging.Formatter('%(asctime)s %(levelname)s %(message)s', '%Y-%m-%d %H:%M:%S')
    h = RotatingFileHandler(pfad, maxBytes=1_000_000, backupCount=3, encoding='utf-8')
    h.setFormatter(fmt)
    log.addHandler(h)
    c = logging.StreamHandler(sys.stdout)
    c.setFormatter(fmt)
    log.addHandler(c)
    return log


# ---------- Server-Zugriff
class Server:
    def __init__(self, basis, schluessel, log):
        self.basis = basis
        self.schluessel = schluessel
        self.log = log

    def _anfrage(self, pfad, methode='GET', daten=None, timeout=30):
        req = urllib.request.Request(self.basis + pfad, method=methode)
        req.add_header('Authorization', 'Bearer ' + self.schluessel)
        req.add_header('User-Agent', 'AMB-Connector/' + VERSION)
        body = None
        if daten is not None:
            body = json.dumps(daten).encode('utf-8')
            req.add_header('Content-Type', 'application/json')
        return urllib.request.urlopen(req, body, timeout=timeout)

    def pruefen(self):
        with self._anfrage('/api/v1/praxis/status') as r:
            return json.loads(r.read().decode('utf-8'))

    def neue_anmeldungen(self):
        with self._anfrage('/api/v1/praxis/anmeldungen?status=neu') as r:
            return json.loads(r.read().decode('utf-8')).get('anmeldungen', [])

    def pdf_laden(self, anmeldung_id, zielpfad):
        teil = zielpfad + '.part'
        with self._anfrage('/api/v1/praxis/anmeldungen/%s/pdf' % anmeldung_id, timeout=120) as r, open(teil, 'wb') as f:
            shutil.copyfileobj(r, f)
        with open(teil, 'rb') as f:
            if f.read(5) != b'%PDF-':
                os.remove(teil)
                raise ValueError('Antwort ist keine PDF-Datei')
        os.replace(teil, zielpfad)

    def bestaetigen(self, anmeldung_id, dateiname):
        with self._anfrage('/api/v1/praxis/anmeldungen/%s/abgeholt' % anmeldung_id, 'POST', {'datei': dateiname}) as r:
            return r.status in (200, 204)


# ---------- Dateien
def sicherer_name(name):
    name = re.sub(r'[^0-9A-Za-zÄÖÜäöüß._-]+', '-', name).strip('.-')
    return name or 'Anmeldung.pdf'


def freier_pfad(ordner, name):
    basis, ext = os.path.splitext(name)
    pfad = os.path.join(ordner, name)
    n = 2
    while os.path.exists(pfad):
        pfad = os.path.join(ordner, '%s_(%d)%s' % (basis, n, ext))
        n += 1
    return pfad


def aufraeumen(ordner, erledigt, tage, log):
    if tage <= 0:
        return
    grenze = time.time() - tage * 86400
    ziel = os.path.join(ordner, erledigt)
    for name in os.listdir(ordner):
        pfad = os.path.join(ordner, name)
        if not os.path.isfile(pfad) or not name.lower().endswith('.pdf') or not any(t in name for t in ('_Anmeldung_', '_Goniometer_')):
            continue  # nur eigene Dateien anfassen, keine Scans der Praxis
        if os.path.getmtime(pfad) < grenze:
            os.makedirs(ziel, exist_ok=True)
            shutil.move(pfad, freier_pfad(ziel, name))
            log.info('Aufgeräumt (älter als %d Tage): %s', tage, name)


# ---------- Ein Durchlauf
def durchlauf(k, server, log):
    ordner = k['importordner']
    if not os.path.isdir(ordner):
        log.error('Importordner fehlt: %s', ordner)
        return 0
    try:
        liste = server.neue_anmeldungen()
    except urllib.error.HTTPError as e:
        log.error('Server antwortet mit Fehler %s (%s)', e.code, 'Praxis-Schlüssel prüfen' if e.code in (401, 403) else e.reason)
        return 0
    except (urllib.error.URLError, OSError) as e:
        log.warning('Server nicht erreichbar: %s', getattr(e, 'reason', e))
        return 0
    geholt = 0
    for a in liste:
        aid, name = a.get('id'), sicherer_name(a.get('dateiname', ''))
        if not aid:
            continue
        ziel = freier_pfad(ordner, name)
        try:
            server.pdf_laden(aid, ziel)
            server.bestaetigen(aid, os.path.basename(ziel))
            log.info('Abgeholt: %s', os.path.basename(ziel))
            geholt += 1
        except Exception as e:  # einzelne Datei scheitert -> nächste; beim nächsten Durchlauf erneut
            log.error('Abholung %s fehlgeschlagen: %s', aid, e)
            for rest in (ziel, ziel + '.part'):
                if os.path.exists(rest) and not os.path.getsize(rest):
                    os.remove(rest)
    aufraeumen(ordner, k['erledigt_ordner'], k['aufraeumen_nach_tagen'], log)
    return geholt


def verbindungstest(k, server, log):
    ok = True
    if os.path.isdir(k['importordner']) and os.access(k['importordner'], os.W_OK):
        log.info('Importordner ok: %s', k['importordner'])
    else:
        log.error('Importordner fehlt oder nicht beschreibbar: %s', k['importordner'])
        ok = False
    try:
        st = server.pruefen()
        log.info('Server ok: %s, Praxis: %s', k['server'], st.get('praxis', '?'))
    except urllib.error.HTTPError as e:
        log.error('Server-Fehler %s – %s', e.code, 'Praxis-Schlüssel ungültig' if e.code in (401, 403) else e.reason)
        ok = False
    except (urllib.error.URLError, OSError) as e:
        log.error('Server nicht erreichbar: %s', getattr(e, 'reason', e))
        ok = False
    return ok


def main():
    ap = argparse.ArgumentParser(description='AMB+-Connector')
    ap.add_argument('--config', default=STANDARD_INI)
    ap.add_argument('--once', action='store_true', help='einmal abholen und beenden')
    ap.add_argument('--test', action='store_true', help='nur Verbindung und Ordner prüfen')
    args = ap.parse_args()

    k = lade_konfig(args.config)
    log = richte_protokoll_ein(k['protokoll'])
    if not k['praxis_schluessel']:
        log.error('Kein Praxis-Schlüssel in %s eingetragen.', args.config)
        return 2
    server = Server(k['server'], k['praxis_schluessel'], log)
    log.info('AMB+-Connector %s gestartet (%s)', VERSION, 'Test' if args.test else 'einmalig' if args.once else 'alle %g min' % k['intervall_minuten'])

    if args.test:
        return 0 if verbindungstest(k, server, log) else 1
    if args.once:
        n = durchlauf(k, server, log)
        log.info('%d Anmeldung(en) abgeholt', n)
        return 0
    while True:
        n = durchlauf(k, server, log)
        if n:
            log.info('%d Anmeldung(en) abgeholt', n)
        try:
            time.sleep(k['intervall_minuten'] * 60)
        except KeyboardInterrupt:
            log.info('Beendet')
            return 0


if __name__ == '__main__':
    sys.exit(main())
