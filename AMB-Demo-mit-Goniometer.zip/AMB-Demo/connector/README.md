# AMB+-Connector

Holt neue Anmeldungen (PDF) vom AMB+-Server ab und legt sie im THEORG-Importordner ab,
damit sie über **E-Akte → Blitzimport** in die Patientenakte übernommen werden können.

## Dateien
- `amb_connector.py` – das Programm (Python 3, keine Zusatzpakete)
- `amb_connector.example.ini` – Vorlage für die Konfiguration
- `test_server.py` – Übungs-Server zum lokalen Testen (liefert PDFs aus einem Ordner)

## Einrichtung am THEORG-PC (Windows)
1. Python 3 installieren (python.org, „Add to PATH“ ankreuzen) – später kommt eine fertige `.exe`.
2. Ordner `C:\AMB\` anlegen, die drei Dateien hineinkopieren.
3. `amb_connector.example.ini` nach `amb_connector.ini` kopieren und den **Praxis-Schlüssel** aus dem Praxisportal eintragen. Importordner prüfen (Standard `C:\THEORG\IMPORT`).
4. Test: `python amb_connector.py --test` → muss „Importordner ok“ und „Server ok“ melden.
5. Dauerbetrieb, eine der beiden Varianten:
   - **Aufgabenplanung** (empfohlen): Aufgabe „AMB+-Connector“, Trigger „alle 5 Minuten“, Aktion `python C:\AMB\amb_connector.py --once`, „Ausführen, auch wenn kein Benutzer angemeldet ist“.
   - **Dauerläufer**: `python amb_connector.py` in den Autostart legen (prüft alle 5 Minuten).

## Was der Connector tut
- Fragt den Server nach neuen Anmeldungen, lädt jedes PDF erst als `.part` und benennt es danach um (nie halbe Dateien im Ordner).
- Bestätigt den Empfang erst nach erfolgreichem Speichern; der Server löscht die Anmeldung später.
- Dateiname: `Nachname_Vorname_TT.MM.JJJJ_Anmeldung_JJJJ-MM-TT.pdf` bzw. `…_Goniometer_…` für Messprotokolle; bei gleichem Namen wird `_(2)` angehängt.
- Verschiebt eigene PDFs nach 30 Tagen in `erledigt\` (fremde Scans im Ordner bleiben unberührt).
- Protokoll in `amb_connector.log` (nur Dateinamen und Status, keine Inhalte).
- Nur ausgehende HTTPS-Verbindungen, keine Firewall-Freigabe nötig. Bei Serverausfall wird beim nächsten Durchlauf erneut versucht.

## Schnittstelle zum AMB+-Server (Version 1)
Alle Aufrufe mit `Authorization: Bearer <Praxis-Schlüssel>`.
| Methode | Pfad | Antwort |
|---|---|---|
| GET | `/api/v1/praxis/status` | `{"praxis": "...", "ok": true}` |
| GET | `/api/v1/praxis/anmeldungen?status=neu` | `{"anmeldungen": [{"id": "...", "dateiname": "..."}]}` |
| GET | `/api/v1/praxis/anmeldungen/{id}/pdf` | PDF-Datei |
| POST | `/api/v1/praxis/anmeldungen/{id}/abgeholt` | 204, Body `{"datei": "..."}` |

## Lokal testen
```
python test_server.py ORDNER_MIT_PDFS 8765
# in amb_connector.ini: server = http://127.0.0.1:8765, praxis_schluessel = test-schluessel-123
python amb_connector.py --test
python amb_connector.py --once
```
